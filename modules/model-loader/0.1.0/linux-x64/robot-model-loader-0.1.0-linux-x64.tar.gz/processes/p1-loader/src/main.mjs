import fs from 'node:fs'
import path from 'node:path'
import { sendTcpMessage } from '../../../shared/net/tcp-client.mjs'
import { createEnvelope } from '../../../shared/protocol/envelope.mjs'
import { MessageTypes } from '../../../shared/protocol/message-types.mjs'
import { logEvent } from '../../../shared/observability/logger.mjs'

const host = process.env.ROBOTARIUM_HOST || '127.0.0.1'
const p2Port = Number(process.env.ROBOTARIUM_P2_PORT || 3211)
const assetsRoot = process.env.ROBOTARIUM_ASSETS_DIR || path.join(process.env.HOME || '.', '.local/share/com.kinematictrees.robotarium.viewer/assets')
const centralRobots = path.join(assetsRoot, 'public/Zoo/central/robots')

function findModelPath() {
  if (!fs.existsSync(centralRobots)) return null
  const vendors = fs.readdirSync(centralRobots)
  for (const vendor of vendors) {
    const vp = path.join(centralRobots, vendor)
    if (!fs.statSync(vp).isDirectory()) continue
    const model = fs.readdirSync(vp).find((d) => fs.statSync(path.join(vp, d)).isDirectory())
    if (model) return path.join(vp, model)
  }
  return null
}

const modelPath = process.argv[2] || findModelPath()
if (!modelPath) {
  console.error('No model path found. Pass a model path as argument.')
  process.exit(1)
}

const request = createEnvelope({
  messageType: MessageTypes.ModelLoadRequest,
  source: 'P1',
  target: 'P2',
  payload: {
    modelId: path.basename(modelPath),
    modelPath,
    format: 'urdf',
    initialJointState: [],
  },
})

async function sendWithRetry(maxAttempts = 20, baseDelayMs = 120) {
  let lastError = null
  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    try {
      return await sendTcpMessage({ host, port: p2Port, message: request, timeoutMs: 2000 })
    } catch (error) {
      lastError = error
      const code = error?.code || ''
      const msg = error instanceof Error ? error.message : String(error)
      // Retry only for transient startup/network conditions.
      if (code !== 'ECONNREFUSED' && code !== 'ECONNRESET' && !msg.includes('timeout')) {
        throw error
      }
      if (attempt < maxAttempts) {
        const delayMs = baseDelayMs * attempt
        await new Promise((resolve) => setTimeout(resolve, delayMs))
      }
    }
  }
  throw lastError || new Error('P1 failed to reach P2 after retries')
}

const reply = await sendWithRetry()
logEvent('P1', { requestId: request.requestId, sent: MessageTypes.ModelLoadRequest, received: reply.messageType, payload: reply.payload })
console.log(JSON.stringify(reply, null, 2))
