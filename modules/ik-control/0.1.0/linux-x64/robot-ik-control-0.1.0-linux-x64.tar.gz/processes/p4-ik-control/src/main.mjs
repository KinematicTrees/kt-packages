import path from 'node:path'
import { sendTcpMessage } from '../../../shared/net/tcp-client.mjs'
import { createEnvelope } from '../../../shared/protocol/envelope.mjs'
import { MessageTypes } from '../../../shared/protocol/message-types.mjs'
import { logEvent } from '../../../shared/observability/logger.mjs'
import { listenProcessServer } from '../../../shared/runtime/process-server.mjs'

const host = process.env.ROBOTARIUM_HOST || '127.0.0.1'
const p2Port = Number(process.env.ROBOTARIUM_P2_PORT || 3211)
const p3Port = Number(process.env.ROBOTARIUM_P3_PORT || 3212)
const p4Port = Number(process.env.ROBOTARIUM_P4_PORT || 3213)

const activeModelContext = {
  modelId: null,
  modelPath: null,
  activeModel: null,
  updatedAt: null,
  requestId: null,
}

let lastP3Reload = {
  ok: false,
  at: null,
  error: null,
  reply: null,
}

function inferModelId(payload = {}) {
  if (typeof payload.modelId === 'string' && payload.modelId.trim()) return payload.modelId.trim()

  const candidate =
    (typeof payload.modelPath === 'string' && payload.modelPath) ||
    (typeof payload.activeModel === 'string' && payload.activeModel) ||
    ''

  if (!candidate) return null

  const normalized = candidate.replace(/\/+$/, '')
  const basename = path.basename(normalized)
  return basename || null
}

function updateActiveModelContextFromModelLoaded(payload = {}, requestId = null) {
  const modelId = inferModelId(payload)
  activeModelContext.modelId = modelId
  activeModelContext.modelPath = typeof payload.modelPath === 'string' && payload.modelPath ? payload.modelPath : null
  activeModelContext.activeModel = typeof payload.activeModel === 'string' && payload.activeModel ? payload.activeModel : null
  activeModelContext.updatedAt = new Date().toISOString()
  activeModelContext.requestId = requestId
}

function withActiveModelContext(payload = {}) {
  const merged = { ...payload }
  const incomingModelId = typeof merged.modelId === 'string' ? merged.modelId.trim() : ''

  if (activeModelContext.modelId) {
    // Policy lives in P4: lock solve model context to latest model loaded by P2.
    if (!incomingModelId || incomingModelId !== activeModelContext.modelId) {
      merged.modelId = activeModelContext.modelId
      merged.modelPath = activeModelContext.modelPath || merged.modelPath
      merged.activeModel = activeModelContext.activeModel || merged.activeModel
    }
  }

  return merged
}

async function notifyP3ModelLoaded(modelLoadedEnvelope) {
  try {
    const notifyEnvelope = createEnvelope({
      messageType: MessageTypes.ModelLoaded,
      source: 'P4',
      target: 'P3',
      requestId: modelLoadedEnvelope.requestId,
      payload: modelLoadedEnvelope.payload,
    })

    const reply = await sendTcpMessage({
      host,
      port: p3Port,
      message: notifyEnvelope,
      timeoutMs: 1200,
    })

    return {
      ok: reply?.messageType === MessageTypes.ModelLoaded,
      reply,
    }
  } catch (error) {
    return {
      ok: false,
      error: error instanceof Error ? error.message : String(error),
    }
  }
}

async function solveAndApply({ requestId, payload }) {
  const payloadWithContext = withActiveModelContext(payload)

  if (!payloadWithContext.modelId) {
    return {
      ok: false,
      ikReply: {
        messageType: MessageTypes.Error,
        payload: {
          code: 'E_MODEL_CONTEXT_MISSING',
          message: 'No active model context in P4; load a model in P1 first.',
        },
      },
    }
  }

  const ikRequest = createEnvelope({
    messageType: MessageTypes.IKRequestNormalized,
    source: 'P4',
    target: 'P3',
    requestId,
    payload: payloadWithContext,
  })

  const ikReply = await sendTcpMessage({ host, port: p3Port, message: ikRequest })
  if (ikReply.messageType !== MessageTypes.IKSolution) {
    return { ok: false, ikReply }
  }

  const applyCmd = createEnvelope({
    messageType: MessageTypes.ViewerCommand,
    source: 'P4',
    target: 'P2',
    requestId: ikRequest.requestId,
    payload: {
      command: 'applyJointTargets',
      jointTargets: ikReply.payload.jointTargets || [],
    },
  })

  const applyReply = await sendTcpMessage({ host, port: p2Port, message: applyCmd })
  return { ok: true, ikReply, applyReply, resolvedPayload: payloadWithContext }
}

async function runOnce() {
  const modelId = process.argv[2] || 'test-model'
  const chainId = process.argv[3] || 'right_arm'
  const x = Number(process.argv[4] || 0.25)
  const y = Number(process.argv[5] || -0.1)
  const z = Number(process.argv[6] || 0.7)

  const result = await solveAndApply({
    requestId: undefined,
    payload: {
      modelId,
      chainId,
      target: { position: [x, y, z], orientationQuat: [0, 0, 0, 1] },
      constraints: { maxIterations: 64, tolerance: 0.001 },
    },
  })

  if (!result.ok) {
    console.error(JSON.stringify(result, null, 2))
    process.exit(2)
  }

  logEvent('P4', {
    requestId: result.ikReply.requestId,
    mode: 'once',
    status: 'ok',
    resolvedModelId: result.resolvedPayload?.modelId,
  })
  console.log(JSON.stringify(result, null, 2))
}

async function runServer() {
  await listenProcessServer({
    processId: 'P4',
    host,
    port: p4Port,
    stateRequestType: MessageTypes.P4StateRequest,
    stateResponseType: MessageTypes.P4State,
    getStatePayload: () => ({
      status: 'ready',
      activeModelContext,
      lastP3Reload,
    }),
    onMessage: async (msg) => {
      if (msg.messageType === MessageTypes.ModelLoaded) {
        updateActiveModelContextFromModelLoaded(msg.payload, msg.requestId)

        const modelLoadedForP3 = createEnvelope({
          messageType: MessageTypes.ModelLoaded,
          source: 'P4',
          target: 'P3',
          requestId: msg.requestId,
          payload: {
            modelId: activeModelContext.modelId,
            modelPath: activeModelContext.modelPath,
            activeModel: activeModelContext.activeModel,
          },
        })

        const p3Reload = await notifyP3ModelLoaded(modelLoadedForP3)
        lastP3Reload = {
          ok: p3Reload.ok,
          at: new Date().toISOString(),
          error: p3Reload.error || null,
          reply: p3Reload.reply || null,
        }

        logEvent('P4', {
          requestId: msg.requestId,
          event: 'ModelLoadedForwarded',
          forwardTarget: 'P3',
          forwardOk: p3Reload.ok,
          forwardError: p3Reload.error || null,
        })

        return createEnvelope({
          messageType: MessageTypes.ModelLoaded,
          source: 'P4',
          target: msg.source,
          requestId: msg.requestId,
          payload: {
            acknowledged: true,
            p3Reloaded: p3Reload.ok,
            p3Reply: p3Reload.reply || null,
            p3Error: p3Reload.error || null,
            activeModelContext,
          },
        })
      }

      if (msg.messageType === MessageTypes.IKRequestNormalized) {
        const result = await solveAndApply({ requestId: msg.requestId, payload: msg.payload })
        if (!result.ok) {
          return createEnvelope({
            messageType: MessageTypes.Error,
            source: 'P4',
            target: msg.source,
            requestId: msg.requestId,
            payload: {
              code: 'E_IK_ORCHESTRATION_FAILED',
              requested: {
                chainId: msg.payload?.chainId || null,
                target: msg.payload?.target || null,
              },
              activeModelContext,
              detail: result.ikReply,
            },
          })
        }

        return createEnvelope({
          messageType: MessageTypes.IKSolution,
          source: 'P4',
          target: msg.source,
          requestId: msg.requestId,
          payload: {
            ...result.ikReply.payload,
            modelId: result.resolvedPayload?.modelId || result.ikReply.payload?.modelId,
            applied: result.applyReply?.messageType === MessageTypes.ViewerJointState,
            activeModelContext,
            lastP3Reload,
          },
        })
      }

      return null
    },
  })
}

if (process.argv[2] === '--serve') {
  await runServer()
} else {
  await runOnce()
}
