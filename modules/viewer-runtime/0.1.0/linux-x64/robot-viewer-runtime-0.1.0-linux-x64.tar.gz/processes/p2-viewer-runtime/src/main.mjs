import { sendTcpMessage } from '../../../shared/net/tcp-client.mjs'
import { createEnvelope } from '../../../shared/protocol/envelope.mjs'
import { MessageTypes } from '../../../shared/protocol/message-types.mjs'
import { logEvent } from '../../../shared/observability/logger.mjs'
import { listenProcessServer } from '../../../shared/runtime/process-server.mjs'

const host = process.env.ROBOTARIUM_HOST || '127.0.0.1'
const port = Number(process.env.ROBOTARIUM_P2_PORT || 3211)
const p4Port = Number(process.env.ROBOTARIUM_P4_PORT || 3213)

let activeModel = null
let jointState = []

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

function viewerStatePayload() {
  return {
    status: activeModel ? 'model_loaded' : 'idle',
    activeModel,
    jointState,
  }
}

async function notifyP4ModelLoaded(modelLoadedEnvelope) {
  const maxAttempts = 3

  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    try {
      const notifyEnvelope = createEnvelope({
        messageType: MessageTypes.ModelLoaded,
        source: 'P2',
        target: 'P4',
        requestId: modelLoadedEnvelope.requestId,
        payload: modelLoadedEnvelope.payload,
      })

      const reply = await sendTcpMessage({
        host,
        port: p4Port,
        message: notifyEnvelope,
        timeoutMs: 1200,
      })

      logEvent('P2', {
        requestId: modelLoadedEnvelope.requestId,
        forwarded: MessageTypes.ModelLoaded,
        forwardTarget: 'P4',
        forwardReply: reply?.messageType,
        attempt,
      })
      return
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error)
      logEvent('P2', {
        requestId: modelLoadedEnvelope.requestId,
        forwarded: MessageTypes.ModelLoaded,
        forwardTarget: 'P4',
        forwardError: message,
        attempt,
      })

      if (attempt < maxAttempts) {
        await sleep(80 * attempt)
      }
    }
  }
}

await listenProcessServer({
  processId: 'P2',
  host,
  port,
  stateRequestType: MessageTypes.ViewerStateRequest,
  stateResponseType: MessageTypes.ViewerState,
  getStatePayload: () => viewerStatePayload(),
  onMessage: async (msg) => {
    if (msg.messageType === MessageTypes.ModelLoadRequest) {
      activeModel = msg.payload.viewerRobotPath || msg.payload.modelPath || msg.payload.modelId || null
      jointState = []

      const modelLoaded = createEnvelope({
        messageType: MessageTypes.ModelLoaded,
        source: 'P2',
        target: msg.source,
        requestId: msg.requestId,
        payload: {
          success: true,
          modelId: msg.payload.modelId,
          modelPath: msg.payload.modelPath,
          viewerRobotPath: msg.payload.viewerRobotPath || null,
          activeModel,
          jointCount: 0,
          rootLink: 'base_link',
        },
      })

      // Keep P2 minimal/runtime-focused: emit best-effort model context update to P4,
      // but never block/abort the P1/UI response path.
      void notifyP4ModelLoaded(modelLoaded)

      return modelLoaded
    }

    if (msg.messageType === MessageTypes.ViewerCommand && msg.payload.command === 'applyJointTargets') {
      jointState = msg.payload.jointTargets || []
      return createEnvelope({
        messageType: MessageTypes.ViewerJointState,
        source: 'P2',
        target: msg.source,
        requestId: msg.requestId,
        payload: {
          success: true,
          activeModel,
          jointState,
        },
      })
    }

    return null
  },
})
