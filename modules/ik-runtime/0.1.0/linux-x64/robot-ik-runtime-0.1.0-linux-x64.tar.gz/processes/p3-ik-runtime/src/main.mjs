import fs from 'node:fs'
import path from 'node:path'
import { spawn } from 'node:child_process'
import { createEnvelope } from '../../../shared/protocol/envelope.mjs'
import { MessageTypes } from '../../../shared/protocol/message-types.mjs'
import { logEvent } from '../../../shared/observability/logger.mjs'
import { listenProcessServer } from '../../../shared/runtime/process-server.mjs'

const host = process.env.ROBOTARIUM_HOST || '127.0.0.1'
const port = Number(process.env.ROBOTARIUM_P3_PORT || 3212)
const IK_API_BASE = process.env.ROBOTARIUM_IK_API_BASE || 'http://127.0.0.1:8090'


function ikApiPortFromBase() {
  try {
    const u = new URL(IK_API_BASE)
    if (u.port) return Number(u.port)
    return u.protocol === 'https:' ? 443 : 80
  } catch {
    return 8090
  }
}

async function checkIkApiHealth(timeoutMs = 800) {
  const ctrl = new AbortController()
  const timer = setTimeout(() => ctrl.abort(), timeoutMs)
  try {
    const resp = await fetch(`${IK_API_BASE}/health`, { signal: ctrl.signal })
    return resp.ok
  } catch {
    return false
  } finally {
    clearTimeout(timer)
  }
}

async function ensureIkApiReady() {
  const autostart = (process.env.ROBOTARIUM_IK_API_AUTOSTART || '1') !== '0'
  if (!autostart) return

  if (await checkIkApiHealth()) return

  const supervisor = path.resolve(process.cwd(), 'scripts/ik-api-supervisor.sh')
  if (!fs.existsSync(supervisor)) {
    logEvent('P3', { event: 'ik_api_autostart_missing_supervisor', supervisor })
    return
  }

  const ikPort = String(ikApiPortFromBase())
  try {
    const child = spawn('bash', [supervisor], {
      detached: true,
      stdio: 'ignore',
      env: {
        ...process.env,
        IK_API_PORT: ikPort,
      },
    })
    child.unref()
    logEvent('P3', { event: 'ik_api_autostart_spawned', pid: child.pid || null, ikApiBase: IK_API_BASE, ikPort })
  } catch (error) {
    logEvent('P3', { event: 'ik_api_autostart_failed', message: error instanceof Error ? error.message : String(error) })
    return
  }

  for (let i = 0; i < 20; i += 1) {
    if (await checkIkApiHealth(600)) {
      logEvent('P3', { event: 'ik_api_ready', ikApiBase: IK_API_BASE })
      return
    }
    await new Promise((resolve) => setTimeout(resolve, 150))
  }

  logEvent('P3', { event: 'ik_api_unreachable_after_autostart', ikApiBase: IK_API_BASE })
}

const activeModelContext = {
  modelId: null,
  modelPath: null,
  activeModel: null,
  updatedAt: null,
  requestId: null,
}

const modelState = {
  tree: null,
  treePath: null,
  rootLink: null,
  sessionByObjective: new Map(),
}

function inferModelId(payload = {}) {
  if (typeof payload.modelId === 'string' && payload.modelId.trim()) return payload.modelId.trim()

  const candidate =
    (typeof payload.modelPath === 'string' && payload.modelPath) ||
    (typeof payload.activeModel === 'string' && payload.activeModel) ||
    ''

  if (!candidate) return null

  const normalized = candidate.replace(/\/+$/, '')
  const basename = path.basename(normalized)
  return basename || null
}

function updateActiveModelContext(payload = {}, requestId = null) {
  activeModelContext.modelId = inferModelId(payload)
  activeModelContext.modelPath = typeof payload.modelPath === 'string' && payload.modelPath ? payload.modelPath : null
  activeModelContext.activeModel = typeof payload.activeModel === 'string' && payload.activeModel ? payload.activeModel : null
  activeModelContext.updatedAt = new Date().toISOString()
  activeModelContext.requestId = requestId
}

function getTreePathFromContext() {
  if (!activeModelContext.modelPath) return null
  return path.join(activeModelContext.modelPath, 'tree.json')
}

function getRootLink(tree) {
  const links = Array.isArray(tree?.Links) ? tree.Links : []
  const joints = Array.isArray(tree?.Joints) ? tree.Joints : []
  const childLinks = new Set(joints.map((j) => j?.child).filter(Boolean))
  const root = links.find((l) => l?.name && !childLinks.has(l.name))
  return root?.name || null
}

function collectEffectorLinks(tree) {
  const links = new Set((Array.isArray(tree?.Links) ? tree.Links : []).map((l) => l?.name).filter(Boolean))
  const tags = tree?.Tags && typeof tree.Tags === 'object' ? tree.Tags : {}
  const candidates = []

  for (const [key, value] of Object.entries(tags)) {
    const k = String(key || '').toLowerCase()
    if (!(k.includes('effec') || k.includes('effect') || k.includes('efec'))) continue

    const vals = Array.isArray(value) ? value : [value]
    for (const v of vals) {
      const name = String(v || '').trim()
      if (!name) continue
      if (!links.has(name)) continue
      if (!candidates.includes(name)) candidates.push(name)
    }
  }

  return candidates
}

function resolveObjectiveLink(tree, chainId) {
  const allLinks = (Array.isArray(tree?.Links) ? tree.Links : [])
    .map((l) => l?.name)
    .filter(Boolean)
  const effectors = collectEffectorLinks(tree)

  const chainRaw = String(chainId || '').trim()
  const chain = chainRaw.toLowerCase()

  // First: explicit chain match against link names (exact/contains)
  if (chain) {
    const exact = allLinks.find((name) => String(name).toLowerCase() === chain)
    if (exact) return exact

    const fuzzy = allLinks.find((name) => String(name).toLowerCase().includes(chain))
    if (fuzzy) return fuzzy
  }

  // Second: fall back to declared effectors in tags.
  if (effectors.length) return effectors[0]

  // Last resort: if no chain/effectors available, fail explicitly.
  throw new Error(`No objective link resolved for chainId='${chainId || ''}'`)
}

function getJointNames(tree) {
  return (Array.isArray(tree?.Joints) ? tree.Joints : [])
    .map((j) => j?.name)
    .filter(Boolean)
}

function resetModelState() {
  modelState.tree = null
  modelState.treePath = null
  modelState.rootLink = null
  modelState.sessionByObjective.clear()
}

function loadModelTreeOrThrow() {
  const treePath = getTreePathFromContext()
  if (!treePath) throw new Error('No active model path in P3 context')
  if (!fs.existsSync(treePath)) throw new Error(`tree.json missing: ${treePath}`)

  const raw = fs.readFileSync(treePath, 'utf8')
  const tree = JSON.parse(raw)
  const rootLink = getRootLink(tree)
  if (!rootLink) throw new Error('Unable to infer root link from tree.json')

  modelState.tree = tree
  modelState.treePath = treePath
  modelState.rootLink = rootLink
  modelState.sessionByObjective.clear()
}

async function ikApi(pathname, body) {
  const res = await fetch(`${IK_API_BASE}${pathname}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })

  const text = await res.text()
  let json = null
  try { json = text ? JSON.parse(text) : null } catch {}

  if (!res.ok) {
    throw new Error(`IK API ${pathname} failed (${res.status}): ${text || 'no body'}`)
  }

  return json || {}
}

async function ensureSession(objectiveLink) {
  const cached = modelState.sessionByObjective.get(objectiveLink)
  if (cached?.sessionId) return cached.sessionId

  if (!modelState.treePath || !modelState.rootLink) {
    throw new Error('Model tree not loaded in P3')
  }

  const payload = {
    treeJsonPath: modelState.treePath,
    rootLink: modelState.rootLink,
    objectiveLinks: [objectiveLink],
    populationSize: 20,
    generations: 4,
    elites: 3,
    collisionSigma: 0,
  }

  const created = await ikApi('/session/create', payload)
  const sessionId = created?.sessionId
  if (!sessionId) throw new Error('IK API returned no sessionId')

  modelState.sessionByObjective.set(objectiveLink, {
    sessionId,
    createdAt: new Date().toISOString(),
  })

  return sessionId
}

async function solveTrueIK(payload) {
  if (!modelState.tree) {
    loadModelTreeOrThrow()
  }

  const objectiveLink = resolveObjectiveLink(modelState.tree, payload?.chainId)
  const sessionId = await ensureSession(objectiveLink)

  const tx = Number(payload?.target?.position?.[0])
  const ty = Number(payload?.target?.position?.[1])
  const tz = Number(payload?.target?.position?.[2])
  if (![tx, ty, tz].every(Number.isFinite)) {
    throw new Error('Target position must be finite [x,y,z]')
  }

  const solved = await ikApi('/session/solve', {
    sessionId,
    objectiveIndex: 0,
    target: [tx, ty, tz],
  })

  if (!solved?.ok) {
    throw new Error(`IK solve returned not-ok for objective '${objectiveLink}'`)
  }

  const solution = Array.isArray(solved?.solution) ? solved.solution : []
  const jointNames = getJointNames(modelState.tree)

  if (!jointNames.length || !solution.length) {
    throw new Error('IK solution missing joints or solution values')
  }

  const n = Math.min(jointNames.length, solution.length)
  const jointTargets = []
  for (let i = 0; i < n; i += 1) {
    const name = jointNames[i]
    const value = Number(solution[i])
    if (!name || !Number.isFinite(value)) continue
    jointTargets.push({ joint: name, value })
  }

  if (!jointTargets.length) {
    throw new Error('IK solution did not yield any finite joint targets')
  }

  return {
    objectiveLink,
    jointTargets,
    objectivePosition: solved?.objectivePosition || null,
    stats: solved?.stats || null,
  }
}

await ensureIkApiReady()

await listenProcessServer({
  processId: 'P3',
  host,
  port,
  stateRequestType: MessageTypes.P3StateRequest,
  stateResponseType: MessageTypes.P3State,
  getStatePayload: () => ({
    status: 'ready',
    activeModelContext,
    solverMode: 'go-ik-session',
    modelState: {
      treePath: modelState.treePath,
      rootLink: modelState.rootLink,
      sessions: Array.from(modelState.sessionByObjective.keys()),
    },
  }),
  onMessage: async (msg) => {
    if (msg.messageType === MessageTypes.ModelLoaded) {
      updateActiveModelContext(msg.payload, msg.requestId)

      let loadError = null
      try {
        loadModelTreeOrThrow()
      } catch (error) {
        loadError = error instanceof Error ? error.message : String(error)
        resetModelState()
      }

      return createEnvelope({
        messageType: MessageTypes.ModelLoaded,
        source: 'P3',
        target: msg.source,
        requestId: msg.requestId,
        payload: {
          acknowledged: true,
          activeModelContext,
          loadError,
          solverMode: 'go-ik-session',
          modelState: {
            treePath: modelState.treePath,
            rootLink: modelState.rootLink,
            sessions: Array.from(modelState.sessionByObjective.keys()),
          },
        },
      })
    }

    if (msg.messageType === MessageTypes.IKRequestNormalized) {
      try {
        const solved = await solveTrueIK(msg.payload)
        return createEnvelope({
          messageType: MessageTypes.IKSolution,
          source: 'P3',
          target: msg.source,
          requestId: msg.requestId,
          payload: {
            status: 'ok',
            modelId: msg.payload.modelId,
            chainId: msg.payload.chainId,
            objectiveLink: solved.objectiveLink,
            jointTargets: solved.jointTargets,
            objectivePosition: solved.objectivePosition,
            solverStats: {
              mode: 'go-ik-session',
              apiStats: solved.stats,
            },
            activeModelContext,
          },
        })
      } catch (error) {
        return createEnvelope({
          messageType: MessageTypes.Error,
          source: 'P3',
          target: msg.source,
          requestId: msg.requestId,
          payload: {
            code: 'E_IK_SOLVE_FAILED',
            message: error instanceof Error ? error.message : String(error),
          },
        })
      }
    }

    return null
  },
  readyMeta: { solverMode: 'go-ik-session', ikApiBase: IK_API_BASE },
})
