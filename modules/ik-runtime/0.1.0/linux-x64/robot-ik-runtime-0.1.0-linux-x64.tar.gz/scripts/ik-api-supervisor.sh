#!/usr/bin/env bash
set -euo pipefail

KINEMATICS_GO_DIR="${KINEMATICS_GO_DIR:-$HOME/KinematicTrees/kinematics_go}"
IK_API_PORT="${IK_API_PORT:-8090}"
LOG_FILE="${IK_API_LOG_FILE:-/tmp/robotarium-ik-api-supervisor.log}"

if [[ ! -d "$KINEMATICS_GO_DIR" ]]; then
  echo "[ik-supervisor] missing kinematics_go dir: $KINEMATICS_GO_DIR" >>"$LOG_FILE"
  exit 1
fi

if ! command -v go >/dev/null 2>&1; then
  echo "[ik-supervisor] go not found" >>"$LOG_FILE"
  exit 1
fi

while true; do
  echo "[ik-supervisor] starting IK API on :$IK_API_PORT at $(date -Iseconds)" >>"$LOG_FILE"
  (
    cd "$KINEMATICS_GO_DIR"
    KINEMATICS_SERVER_ADDR=":$IK_API_PORT" go run ./cmd/server/main.go
  ) >>"$LOG_FILE" 2>&1 || true
  echo "[ik-supervisor] IK API exited; restarting in 0.5s" >>"$LOG_FILE"
  sleep 0.5
done
