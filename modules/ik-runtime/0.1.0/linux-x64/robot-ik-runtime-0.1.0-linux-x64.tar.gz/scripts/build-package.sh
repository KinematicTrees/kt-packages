#!/usr/bin/env bash
set -euo pipefail
PACKAGE_NAME="$(node -e "const p=require('./package.json'); console.log((p.metadata&&p.metadata.name)||p.name||'kt-module')")"
PACKAGE_VERSION="${PACKAGE_VERSION:-$(node -e "const p=require('./package.json'); console.log((p.metadata&&p.metadata.version)||p.version||'0.0.0')")}"
TARGET_PLATFORM="${TARGET_PLATFORM:-linux-x64}"
OUT_DIR="${OUT_DIR:-/out}"
mkdir -p "$OUT_DIR"
include=(package.json)
for p in processes shared scripts; do
  [ -e "$p" ] && include+=("$p")
done
tar -czf "$OUT_DIR/${PACKAGE_NAME}-${PACKAGE_VERSION}-${TARGET_PLATFORM}.tar.gz" "${include[@]}"
(
  cd "$OUT_DIR"
  sha256sum "${PACKAGE_NAME}-${PACKAGE_VERSION}-${TARGET_PLATFORM}.tar.gz" > checksums.txt
)
cat > "$OUT_DIR/sbom.spdx.json" <<JSON
{"spdxVersion":"SPDX-2.3","name":"${PACKAGE_NAME}","versionInfo":"${PACKAGE_VERSION}","dataLicense":"CC0-1.0"}
JSON
cat > "$OUT_DIR/provenance.json" <<JSON
{"packageName":"${PACKAGE_NAME}","version":"${PACKAGE_VERSION}","platform":"${TARGET_PLATFORM}","sourceRepo":"${GITHUB_REPOSITORY:-unknown}","sourceCommit":"${GIT_COMMIT:-unknown}"}
JSON
