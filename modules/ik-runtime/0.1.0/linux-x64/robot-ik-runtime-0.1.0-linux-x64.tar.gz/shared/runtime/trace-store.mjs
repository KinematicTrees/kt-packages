// Shared in-process trace store for runtime-scope UI.
// Keeps a small ring buffer of last N inbound/outbound envelopes per channelKey.

const DEFAULT_MAX = Math.max(1, Number(process.env.ROBOTARIUM_SCOPE_TRACE_MAX || '1'))

const inbound = new Map()
const outbound = new Map()

function push(map, key, value, max) {
  if (!key) return
  const list = map.get(key) || []
  list.push(value)
  while (list.length > max) list.shift()
  map.set(key, list)
}

export function recordInbound(event, maxItems = DEFAULT_MAX) {
  if (!event || !event.channelKey) return
  push(inbound, event.channelKey, event, maxItems)
}

export function recordOutbound(event, maxItems = DEFAULT_MAX) {
  if (!event || !event.channelKey) return
  push(outbound, event.channelKey, event, maxItems)
}

export function snapshot({ maxItems } = {}) {
  const limit = Math.max(1, Number(maxItems || DEFAULT_MAX))
  const toObj = (map) => {
    const out = {}
    for (const [k, v] of map.entries()) {
      if (!Array.isArray(v) || v.length === 0) continue
      out[k] = v.slice(Math.max(0, v.length - limit))
    }
    return out
  }
  return {
    maxItems: limit,
    inbound: toObj(inbound),
    outbound: toObj(outbound),
  }
}
