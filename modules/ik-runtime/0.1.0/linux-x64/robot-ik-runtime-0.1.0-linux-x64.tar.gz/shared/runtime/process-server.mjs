import { createTcpServer } from '../net/tcp-server.mjs'
import { createEnvelope, assertEnvelope } from '../protocol/envelope.mjs'
import { MessageTypes } from '../protocol/message-types.mjs'
import { logEvent } from '../observability/logger.mjs'
import { recordInbound, recordOutbound, snapshot } from './trace-store.mjs'

/**
 * Lightweight canonical wrapper for process TCP servers.
 * Keeps behavior local while centralizing health/state/unsupported handling.
 */
export async function listenProcessServer({
  processId,
  host,
  port,
  stateRequestType = null,
  stateResponseType = null,
  getStatePayload = null,
  onMessage,
  readyMeta = {},
}) {
  if (!processId) throw new Error('listenProcessServer requires processId')
  if (!host) throw new Error('listenProcessServer requires host')
  if (!Number.isFinite(Number(port))) throw new Error('listenProcessServer requires numeric port')
  if (typeof onMessage !== 'function') throw new Error('listenProcessServer requires onMessage handler')

  const server = createTcpServer({
    host,
    port,
    onMessage: async (msg) => {
      assertEnvelope(msg)
      logEvent(processId, { requestId: msg.requestId, messageType: msg.messageType })
      if (msg.messageType !== MessageTypes.HealthPing && msg.messageType !== 'ScopeTraceRequest') {
        try {
          recordInbound({
            at: new Date().toISOString(),
            channelKey: `${msg.source}->${processId}:${msg.messageType}`,
            source: msg.source,
            target: processId,
            messageType: msg.messageType,
            payload: msg.payload ?? {},
          })
        } catch {}
      }

      if (msg.messageType === MessageTypes.HealthPing) {
        return createEnvelope({
          messageType: MessageTypes.HealthPong,
          source: processId,
          target: msg.source,
          requestId: msg.requestId,
          payload: { status: 'ready' },
        })
      }

      if (msg.messageType == 'ScopeTraceRequest') {
        const maxItems = Number(msg?.payload?.maxItems || 1)
        return createEnvelope({
          messageType: 'ScopeTraceState',
          source: processId,
          target: msg.source,
          requestId: msg.requestId,
          payload: snapshot({ maxItems }),
        })
      }

      if (
        stateRequestType &&
        stateResponseType &&
        msg.messageType === stateRequestType
      ) {
        return createEnvelope({
          messageType: stateResponseType,
          source: processId,
          target: msg.source,
          requestId: msg.requestId,
          payload: typeof getStatePayload === 'function' ? getStatePayload(msg) : { status: 'ready' },
        })
      }

      const reply = await onMessage(msg)
      if (reply) {
        if (reply.messageType !== 'ScopeTraceState') {
          try {
            recordOutbound({
              at: new Date().toISOString(),
              channelKey: `${processId}->${msg.source}:${reply.messageType}`,
              source: processId,
              target: msg.source,
              messageType: reply.messageType,
              payload: reply.payload ?? {},
            })
          } catch {}
        }
        return reply
      }

      return createEnvelope({
        messageType: MessageTypes.Error,
        source: processId,
        target: msg.source,
        requestId: msg.requestId,
        payload: { code: 'E_UNSUPPORTED_MESSAGE', message: msg.messageType },
      })
    },
  })

  await server.listen()
  logEvent(processId, { status: 'ready', host, port, ...readyMeta })
  return server
}
