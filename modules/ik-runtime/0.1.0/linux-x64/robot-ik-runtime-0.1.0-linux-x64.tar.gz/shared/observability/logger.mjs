export function logEvent(process, fields = {}) {
  const row = {
    ts: new Date().toISOString(),
    process,
    ...fields,
  }
  console.log(JSON.stringify(row))
}
