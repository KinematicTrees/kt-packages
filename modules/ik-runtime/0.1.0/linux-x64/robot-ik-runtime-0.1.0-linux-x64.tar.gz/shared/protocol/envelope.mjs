import crypto from 'node:crypto'

export const PROTOCOL_VERSION = '1.0'

export function createEnvelope({ messageType, source, target, requestId, payload }) {
  return {
    protocolVersion: PROTOCOL_VERSION,
    messageType,
    requestId: requestId || crypto.randomUUID(),
    timestamp: new Date().toISOString(),
    source,
    target,
    payload: payload ?? {},
  }
}

export function assertEnvelope(msg) {
  const required = ['protocolVersion', 'messageType', 'requestId', 'timestamp', 'source', 'target']
  for (const key of required) {
    if (!(key in msg)) throw new Error(`E_SCHEMA_INVALID: missing ${key}`)
  }
  if (msg.protocolVersion !== PROTOCOL_VERSION) {
    throw new Error('E_UNSUPPORTED_PROTOCOL_VERSION')
  }
}
