export function parseLines(buffer, chunk) {
  const data = buffer + chunk.toString('utf8')
  const lines = data.split('\n')
  const remainder = lines.pop() ?? ''
  const messages = []
  for (const line of lines) {
    const t = line.trim()
    if (!t) continue
    messages.push(JSON.parse(t))
  }
  return { remainder, messages }
}

export function encodeMessage(msg) {
  return JSON.stringify(msg) + '\n'
}
