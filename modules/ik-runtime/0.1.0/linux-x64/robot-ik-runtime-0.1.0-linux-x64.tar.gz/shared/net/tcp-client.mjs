import net from 'node:net'
import { encodeMessage, parseLines } from './ndjson.mjs'
import { recordInbound, recordOutbound } from '../runtime/trace-store.mjs'

export async function sendTcpMessage({ host, port, message, timeoutMs = 3000 }) {
  return new Promise((resolve, reject) => {
    const socket = net.createConnection({ host, port })
    let remainder = ''
    const timer = setTimeout(() => {
      socket.destroy()
      reject(new Error('timeout'))
    }, timeoutMs)

    socket.on('connect', () => {
      try {
        const local = message?.source || 'UNKNOWN'
        const remote = message?.target || 'UNKNOWN'
        recordOutbound({
          at: new Date().toISOString(),
          channelKey: `${local}->${remote}:${message?.messageType || 'UNKNOWN'}` ,
          source: local,
          target: remote,
          messageType: message?.messageType,
          payload: message?.payload ?? {},
        })
      } catch {}
      socket.write(encodeMessage(message))
    })

    socket.on('data', (chunk) => {
      const parsed = parseLines(remainder, chunk)
      remainder = parsed.remainder
      if (parsed.messages.length > 0) {
        const reply = parsed.messages[0]
        try {
          const local = message?.source || 'UNKNOWN'
          const remote = message?.target || 'UNKNOWN'
          const replySource = reply?.source || remote
          recordInbound({
            at: new Date().toISOString(),
            channelKey: `${replySource}->${local}:${reply?.messageType || 'UNKNOWN'}` ,
            source: replySource,
            target: local,
            messageType: reply?.messageType,
            payload: reply?.payload ?? {},
          })
        } catch {}
        clearTimeout(timer)
        resolve(reply)
        socket.end()
      }
    })

    socket.on('error', (err) => {
      clearTimeout(timer)
      reject(err)
    })
  })
}
