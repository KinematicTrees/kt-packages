import net from 'node:net'
import { parseLines, encodeMessage } from './ndjson.mjs'

export function createTcpServer({ host, port, onMessage }) {
  const server = net.createServer({ allowHalfOpen: true }, (socket) => {
    let remainder = ''
    socket.on('data', async (chunk) => {
      try {
        const parsed = parseLines(remainder, chunk)
        remainder = parsed.remainder
        for (const msg of parsed.messages) {
          const reply = await onMessage(msg)
          if (reply) socket.write(encodeMessage(reply))
        }
      } catch (err) {
        socket.write(encodeMessage({ messageType: 'Error', payload: { code: 'E_SCHEMA_INVALID', message: String(err.message || err) } }))
      }
    })
  })
  return {
    listen: () => new Promise((resolve) => server.listen(port, host, resolve)),
    close: () => new Promise((resolve) => server.close(resolve)),
  }
}
